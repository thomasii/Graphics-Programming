#include "TextureCoordinateFunctions.h"

dvec2 calcSphericalTextCoord(const dvec3& objectCoord, const double& sRepeats, const double& tRepeats, AXIS axis)
{
	double s, t;

	dvec3 normObjCoord = glm::normalize(objectCoord);

	// atan2 returns and angle in the range [-PI, PI].
	// Division of the angle by TWO_PI shifts to the range [-0.5 0.5]
	// Addition of 0.5 shifts the range to [0.0 1.0]
	// asin returns values in the range [PI/2 PI/2]
	// Division by PI shifts to the range [-0.5 0.5]
	// Su

	if (axis == X_AXIS) {
		s = atan2(normObjCoord.z, normObjCoord.y) / TWO_PI + 0.5;
		t = 0.5 - (asin(normObjCoord.x) / PI);
	}
	else if (axis == Y_AXIS) {
		s = atan2(normObjCoord.x, normObjCoord.z) / TWO_PI + 0.5;
		t = 0.5 - (asin(normObjCoord.y) / PI);
	}
	else { // Z_AXIS
		s = atan2(normObjCoord.y, normObjCoord.x) / TWO_PI + 0.5;
		t = 0.5 - (asin(normObjCoord.z) / PI);
	}

	s *= sRepeats;
	t *= tRepeats;

	return glm::dvec2(s, t);
}

dvec2 calcPlanarTextCoord(const dvec3& objectCoord, const double& width, const double& height, AXIS axis)
{
	double s, t;
	if (axis == X_AXIS) {
		s = objectCoord.z / width + 0.5;
		t = 0.5 - objectCoord.y / height;
	}
	else if (axis == Y_AXIS) {
		s = objectCoord.x / width + 0.5;
		t = 0.5 - objectCoord.z / height;
	}
	else { // Z_AXIS	
		s = objectCoord.x / width + 0.5;
		t = 0.5 - objectCoord.y / height;
	}

	return dvec2(s, t);
}

dvec2 calcCylindricalTextCoord(const dvec3& objectCoord, const double& sRepeats, const double& cylinderHeight, AXIS axis)
{
	double s, t;

	if (axis == X_AXIS) {
		s = atan2(objectCoord.z, objectCoord.y) / TWO_PI + 0.5;
		t = 0.5 - objectCoord.x / cylinderHeight;
	}
	else if (axis == Y_AXIS) {
		s = atan2(objectCoord.x, objectCoord.z) / TWO_PI + 0.5;
		t = 0.5 - objectCoord.y / cylinderHeight;
	}
	else { // Z_AXIS
		s = atan2(objectCoord.y, objectCoord.x) / TWO_PI + 0.5;
		t = 0.5 - objectCoord.z / cylinderHeight;
	}

	s *= sRepeats;

	return glm::dvec2(s, t);
}

