#pragma once

#include "Defines.h"

// Enumeration type for specifying the axis about which polar coordinates are to be generated.
enum AXIS { X_AXIS, Y_AXIS, Z_AXIS };

/**
 * @fn	dvec2 calcSphericalTextCoord(const dvec3& objectCoord, const double& sRepeats = 1.0, const double& tRepeats = 1.0, AXIS axis = X_AXIS);
 *
 * @brief	Finds uv or st coordinates of an intercept, vertex, or fragment for a spherically mapped
 * 			texture.
 *
 * @author	Bachmaer
 * @date	7/3/2019
 *
 * @param	objectCoord	The object coordinate of the point for which a texture coordinate is be calculated.
 * @param	sRepeats   	(Optional) Number of texture copies around the generation axis.
 * @param	tRepeats   	(Optional) Number of texture copies along the generations axis.
 * @param	axis	   	(Optional) The axis along which the texture coordinates are generated (tRepeats direction).
 *
 * @returns	The calculated spherical texture coordinates.
 */
dvec2 calcSphericalTextCoord(const dvec3& objectCoord, const double& sRepeats = 1.0, const double& tRepeats = 1.0, AXIS axis = X_AXIS);

/**
 * @fn	dvec2 calculatePlanarTextureCoordinates(const dvec3& objectCoord, const double& width = 1.0, const double& height = 1.0, AXIS axis = X_AXIS);
 *
 * @brief	Finds uv or st coordinates of an intercept, vertex, or fragment for a planar mapped texture.
 *
 * @author	Bachmaer
 * @date	7/3/2019
 *
 * @param	objectCoord	The object coordinate.
 * @param	width	   	(Optional) The width of each texture copy.
 * @param	height	   	(Optional) The height of each texture copy.
 * @param	axis	   	(Optional) The axis along which the texture coordinates are generated.
 *
 * @returns	The calculated planar texture coordinates.
 */
dvec2 calcPlanarTextCoord(const dvec3& objectCoord, const double& width = 1.0, const double& height = 1.0, AXIS axis = X_AXIS);

/**
 * @fn	dvec2 calcCylindricalTextCoord(const dvec3& objectCoord, const double& sRepeats = 1.0, const double& cylinderHeight = 1.0, AXIS axis = X_AXIS);
 *
 * @brief	Finds uv or st coordinates of an intercept, vertex, or fragment for a  cylindrical mapped texture.
 *
 * @author	Bachmaer
 * @date	7/3/2019
 *
 * @param	objectCoord   	The local coordinates.
 * @param	sRepeats	  	(Optional) The number of times to repeat the texture going around the cylinder.
 * @param	cylinderHeight	(Optional) The height of the cylinder.
 * @param	axis		  	(Optional) The axis around which the cylinder is oriented.
 *
 * @returns	The calculated cylindrical texture coordinates.
 */
dvec2 calcCylindricalTextCoord(const dvec3& objectCoord, const double& sRepeats = 1.0, const double& cylinderHeight = 1.0, AXIS axis = X_AXIS);


