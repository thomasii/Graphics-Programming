#include "Plane.h"
#include "TextureCoordinateFunctions.h"
#include "TextureImage.h"

Plane::Plane(const dvec3 & point, const dvec3 & normal, const color & material)
	: ImplicitSurface(material), a(point), n(normalize(normal))
{
}


Plane::Plane(std::vector<dvec3> vertices, const color & material)
	: ImplicitSurface(material)
{
	a = vertices[0];

	n = glm::normalize(glm::cross(vertices[2] - vertices[1], vertices[0] - vertices[1]));
}


HitRecord Plane::findIntersect(const Ray& ray)
{
	double denominator = glm::dot(ray.direct, n);

	HitRecord hitRecord;
	double t;

	if (denominator != 0.0)
	{
		HitRecord hitRecord;
		double denominator = glm::dot(ray.direct, n);
		double numerator = glm::dot(a - ray.origin, n);

		// Check if 
		if (denominator != 0) {

			double t = numerator / denominator;

			if (t < 0) {
				hitRecord.t = INFINITY;
				return hitRecord;
			}

			// Check for back face intersection
			if (glm::dot(ray.direct, n) > 0) {

				//Reverse the normal for back face intersections
				hitRecord.surfaceNormal = -n;

			}
			else {
				hitRecord.surfaceNormal = n;

			}
			hitRecord.t = t;
			hitRecord.material = material;

			// Set hit record information about the intersetion.
			hitRecord.interceptPoint = ray.origin + t * ray.direct;

			// Pass the position of the intercept point relative to the center of the object
			hitRecord.uv = calcPlanarTextCoord(hitRecord.interceptPoint - a, 32, 32, (AXIS) 1);



		}
		else {

			// Set parameter, t, in the hit record to indicate "no intersection."
			hitRecord.t = INFINITY;
		}

		return hitRecord;
	}

}

	



