#include "RayTracer.h"


RayTracer::RayTracer(FrameBuffer& cBuffer, color defaultColor)
	:colorBuffer(cBuffer), defaultColor(defaultColor), recursionDepth(2)
{

}


void RayTracer::setCameraFrame(const dvec3& viewPosition, const dvec3& viewingDirection, dvec3 up)
{

	// TODO
	this->eye = viewPosition;
	this->w = normalize(-viewingDirection);
	this->u = normalize(cross(up, w));
	this->v = normalize(cross(w, u));
//make sphere	

} // end setCameraFrame


void RayTracer::calculatePerspectiveViewingParameters(const double& verticalFieldOfViewDegrees)
{

	// TODO define bottomLinit, topLimit, rightlIMIT, LEFTlIMIT, DISTTOPlane, nx, ny
	nx = (double)colorBuffer.getWindowWidth();
	ny = (double)colorBuffer.getWindowHeight();
	this->topLimit = 1;
	this->bottomLimit = -this->topLimit;
	this->rightLimit = this->topLimit * (this->nx/this->ny);
	this->leftLimit = -this->rightLimit;
	double radians = PI * verticalFieldOfViewDegrees / 180;
	this->distToPlane = this->topLimit / tan(verticalFieldOfViewDegrees /2);

	renderPerspectiveView = true; // generate perspective view rays

} // end calculatePerspectiveViewingParameters


void RayTracer::calculateOrthographicViewingParameters(const double& viewPlaneHeight)
{
	topLimit = fabs(viewPlaneHeight) / 2.0;

	rightLimit = topLimit * ((double)colorBuffer.getWindowWidth() / colorBuffer.getWindowHeight()); // Set r based on aspect ratio and height of plane

	// Make view plane symetrical about the viewing direction
	leftLimit = -rightLimit;
	bottomLimit = -topLimit;

	// Calculate the distance between pixels in the horizontal and vertical directions
	nx = (double)colorBuffer.getWindowWidth();
	ny = (double)colorBuffer.getWindowHeight();

	distToPlane = 0.0; // Rays start on the view plane

	renderPerspectiveView = false; // generate orthographic view rays

} // end calculateOrthographicViewingParameters


Ray RayTracer::getOrthoViewRay(const int& x, const int& y)
{
	Ray orthoViewRay;

	dvec2 uv = getImagePlaneCoordinates(x, y);

	orthoViewRay.origin = eye + uv.x * u + uv.y * v;
	orthoViewRay.direct = -w;

	return orthoViewRay;

} // end getOrthoViewRay


Ray RayTracer::getPerspectiveViewRay(const int& x, const int& y)
{
	Ray perspectiveViewRay;

	// TODO
	dvec2 uv = getImagePlaneCoordinates(x, y);

	perspectiveViewRay.direct = normalize((-this->distToPlane * this->w) + (uv.x * this->u) + (uv.y * this->v));
	perspectiveViewRay.origin = eye;
	

	return perspectiveViewRay;

} // end getPerspectiveViewRay


dvec2 RayTracer::getImagePlaneCoordinates(const int& x, const int& y)
{
	dvec2 s;
	
	// TODO
	s.x = (x + 0.5) * ((this->rightLimit - this->leftLimit)/this->nx) + this->leftLimit;
	s.y = (y + 0.5) * ((this->topLimit - this->bottomLimit)/this->ny) + this->bottomLimit;
	return s;

} // end getImagePlaneCoordinates


void RayTracer::raytraceScene()
{
	// Iterate through each and every pixel in the rendering window
	// TODO
	for (int j = 0; j < this->colorBuffer.getWindowHeight(); j++)
	{
		for (int i = 0; i < this->colorBuffer.getWindowWidth(); i++)
		{

			Ray ray;

			if (this->renderPerspectiveView)
			{
				ray = this->getPerspectiveViewRay(i, j);
			}
			else {
				ray = this->getOrthoViewRay(i, j);
			}
			color result = traceRay(ray);
			this->colorBuffer.setPixel(i, j, result);
		}
	}

} // end raytraceScene





color RayTracer::traceRay(const Ray& ray, int recursionLevel)
{

	if (recursionLevel <= this->recursionDepth)
	{

		// Find surface intersection that is closest to the origin of the viewRay
		HitRecord closestHit = findClosestIntersection(ray);

		if (closestHit.t == INFINITY)
		{
			return defaultColor;
		}
		else
		{

			//Determine distance


			color totalLight = closestHit.material.getEmisive();
			for (auto& light : lights) {


				double distToLight = light->getLightDistance(closestHit.interceptPoint);
				dvec3 shadowDirection = glm::normalize(light->getLightVector(closestHit.interceptPoint));

				Ray shadowFeeler;

				shadowFeeler.direct = shadowDirection;
				shadowFeeler.origin = closestHit.interceptPoint + EPSILON * closestHit.surfaceNormal;

				HitRecord shadowRecord = findClosestIntersection(shadowFeeler);

				if (shadowRecord.t >= distToLight)
				{
					totalLight += light->getLocalIllumination(
						-ray.direct, closestHit.interceptPoint,
						closestHit.surfaceNormal,
						closestHit.material, closestHit.uv);
				}
			}

			dvec3 reflectDir = glm::reflect(ray.direct, closestHit.surfaceNormal);

			Ray viewReflectRay(closestHit.interceptPoint + EPSILON * closestHit.surfaceNormal, reflectDir);

			color mirrored = traceRay(viewReflectRay, recursionLevel + 1);

			totalLight += mirrored;

			return totalLight;
		}
		// TODO
	}
	return defaultColor;
	
} // end traceRay


HitRecord RayTracer::findClosestIntersection(const Ray& ray)
{
	HitRecord closestHit;
	closestHit.t = INFINITY;

	// Check if the ray intersects any surfaces in the scene
	for (auto& surface : this->surfaces)
	{
		HitRecord temp = surface->findIntersect(ray);

		if (temp.t < closestHit.t)
		{
			closestHit = temp;
		}
	}
	// TODO

	return closestHit;

} // end findIntersection








