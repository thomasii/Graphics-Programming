#include "Ellipsoid.h"

Ellipsoid::Ellipsoid(dvec3 radi, dvec3 position, color quadColor)
	: QuadricSurface(position, quadColor)
{
	this->A = 1/ pow(radi.x,2);
	this->B = 1/ pow(radi.y, 2);
	this->C = 1/ pow(radi.z, 2);
	this->D = 0;
	this->E = 0;
	this->F = 0;
	this->G = 0;
	this->H = 0;
	this->I = 0;
	this->J = -1;
}