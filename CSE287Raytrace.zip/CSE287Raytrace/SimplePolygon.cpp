#include "SimplePolygon.h"
SimplePolygon::SimplePolygon(std::vector<dvec3> vertices, const color& mat)
	:Plane(vertices,mat)
{
	this->vertices = vertices;
	this->leadEdge1 = vertices[1] - vertices[0];
	this->leadEdge2 = vertices[2] - vertices[1];
	this->leadEdge3 = vertices[0] - vertices[2];
}

HitRecord SimplePolygon::findIntersect(const Ray& ray)
{
	double denominator = glm::dot(ray.direct, n);

	HitRecord hitRecord;
	double t;

	if (denominator != 0.0)
	{
		HitRecord hitRecord;
		double denominator = glm::dot(ray.direct, n);
		double numerator = glm::dot(a - ray.origin, n);

			double t = numerator / denominator;

			if (t < 0) {
				hitRecord.t = INFINITY;
				return hitRecord;
			}

			// Check for back face intersection
			if (glm::dot(ray.direct, n) > 0) {

				//Reverse the normal for back face intersections
				hitRecord.surfaceNormal = -n;

			}
			else {
				hitRecord.surfaceNormal = n;

			}

			//Check for interior point
					hitRecord.t = t;
					hitRecord.material = material;

					// Set hit record information about the intersetion.
					hitRecord.interceptPoint = ray.origin + t * ray.direct;

					dvec3 check1 = glm::cross(this->leadEdge1, hitRecord.interceptPoint - vertices[0]);
					double checkinside1 = glm::dot(check1, hitRecord.interceptPoint);
					dvec3 check2 = glm::cross(this->leadEdge2, hitRecord.interceptPoint - vertices[1]);
					double checkinside2 = glm::dot(check2, hitRecord.interceptPoint);
					dvec3 check3 = glm::cross(this->leadEdge3, hitRecord.interceptPoint - vertices[2]);
					double checkinside3 = glm::dot(check3, hitRecord.interceptPoint);

					if (checkinside1 < 0 || checkinside2 < 0 || checkinside3 < 0)
					{
						hitRecord.t = INFINITY;
						hitRecord.interceptPoint = { NULL,NULL,NULL };
					}

			// Pass the position of the intercept point relative to the center of the object
			//hitRecord.uv = calcPlanarTextCoord(hitRecord.interceptPoint - a, 32, 32, Y_AXIS);
					

					return hitRecord;

	}
	else {

		// Set parameter, t, in the hit record to indicate "no intersection."
		hitRecord.t = INFINITY;
	}

}
