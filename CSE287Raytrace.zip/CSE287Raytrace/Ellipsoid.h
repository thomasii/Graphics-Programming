#pragma once
#include "QuadricSurface.h"
class Ellipsoid : public QuadricSurface
{
public:

	Ellipsoid(dvec3 radi, dvec3 position, color quadColor);

};

