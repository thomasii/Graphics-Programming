#pragma once
#include "Plane.h"
class SimplePolygon :public Plane
{
	public:

	SimplePolygon(std::vector<dvec3> vertices, const color& mat);

	virtual HitRecord findIntersect(const Ray& ray);

	std::vector<dvec3> vertices;

	dvec3 leadEdge1;
	dvec3 leadEdge2;
	dvec3 leadEdge3;
};

