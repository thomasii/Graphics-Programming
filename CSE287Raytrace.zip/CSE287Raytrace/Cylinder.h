#pragma once
#include "QuadricSurface.h"
class Cylinder :public QuadricSurface
{

public: 

	Cylinder(double radius, dvec3 position, color quadColor);

	double radius;

	virtual HitRecord findIntersect(const Ray& ray) override;
};

